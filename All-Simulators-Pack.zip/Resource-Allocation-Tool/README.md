# Resource Allocation Tool

Allocate resources (e.g., water, power) across regions given weights and limits.

## Run
```bash
python -m pip install -r requirements.txt
streamlit run app.py
```
