import pandas as pd
import numpy as np

def compute_scores(df_options, criteria, weights):
    w = np.array(weights) / np.sum(weights) if np.sum(weights)!=0 else np.ones(len(weights))/len(weights)
    scores = df_options[criteria].values.dot(w)
    df = df_options.copy()
    df['Score'] = scores
    df = df.sort_values('Score', ascending=False)
    return df
