# Urban Growth Heatmap Generator

Generates synthetic urban growth maps using simple probabilistic rules and plots heatmaps.

## Run
```bash
python -m pip install -r requirements.txt
streamlit run app.py
```
