# Decision Matrix Generator

Create criteria and weights, add options, score options per criterion, rank results, and export CSV.

## Run
```bash
python -m pip install -r requirements.txt
streamlit run app.py
```
